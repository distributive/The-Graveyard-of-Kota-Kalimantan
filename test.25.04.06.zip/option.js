class Option {
  constructor(id, text, classes) {
    this.id = id;
    this.text = text;
    this.classes = classes;
  }
}
