// TODO: abstract this into anonymous objects?

class Option {
  constructor(id, text, classes) {
    this.id = id;
    this.text = text;
    this.classes = classes;
  }
}
